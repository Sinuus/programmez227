# NumberRecognition
In this repository, I use Opencv, keras and tensorflow to create my own number recognition AI.

First, extract image from zip file or create your dataset.
Run train.py to create the AI, you are free to change parameters,
then run test.py to have a look at the result !
